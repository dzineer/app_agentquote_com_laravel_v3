<?php

namespace Dzineer\SMS;

class SMSNotSentException extends \Exception
{
}
