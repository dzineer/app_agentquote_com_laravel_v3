# Contribution Guidelines

Please submit all issues and pull requests to the [dzineer/dz-sms](https://github.com/dzineer/dz-sms) repository on the develop branch!