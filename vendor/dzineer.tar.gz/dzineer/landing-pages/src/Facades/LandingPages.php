<?php

namespace Dzineer\LandingPages\Facades;

use Illuminate\Support\Facades\Facade;

class LandingPages extends Facade {

	protected static function getFacadeAccessor() {
		return 'LandingPages';
	}

}