<?php

namespace Dzineer\CustomModules\Library\Mediators;

use Dzineer\CustomModules\Library\ModuleMediator;

class CustomModuleMediator extends ModuleMediator {}