<div class="row">
    <div class="col-md-12">

        <div class="row">

            <div class="col-md-12">
                <div class="form-group">
                    <label for="usr">New Group Name:</label>
                    <input type="text" class="form-control group_name">
                </div>
            </div>

            <div class="col-md-12">
                <input type="submit" class="btn btn-primary btn-lg btn-block btn-huge control update-btn mt-3 mb-3" value=" Save ">
            </div>

        </div>
    </div>
</div>
