@extends('adminlte::page')

@section('title')
    {{ config('agentquote.company.name') }}
@endsection

@section('content_header')
    <h1>MicrositePage</h1>
@stop

@section('content')
    <div id="user"></div>
@stop