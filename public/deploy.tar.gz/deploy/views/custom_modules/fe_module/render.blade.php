<div id="final-expense-btn-container" class="btn-container" data-start-field="#start_quote_name_lg">
    <div id="final-expense-btn" class="select-btn" data-insure-type="f" data-insure-name="Final Expense">
        <i class="fa fa-umbrella fa-2" aria-hidden="true"></i>
    </div>
    <h4>Final Expense</h4>
</div>
