<div class="alert alert-success m-t-0 m-b-40 m-0-auto" role="alert">
    <h4 class="alert-heading">Well done!</h4>
    <p>Aww yeah, you successfully read this important alert message. This example text is going to run a bit longer so that you can see how spacing within an alert works with this kind of content.</p>
    <a href="{{ $url }}" target="_blank" class="btn btn-danger btn-lg m-y-40" style="display:block;margin: 0 auto;">{{ $title }}</a>
</div>
