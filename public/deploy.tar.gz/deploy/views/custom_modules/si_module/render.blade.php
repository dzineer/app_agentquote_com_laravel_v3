<div id="TermLife-btn-container" class="btn-container" data-start-field="#start_quote_name_lg">
    <div id="TermLife-btn" class="select-btn" data-insure-type="TermLife" data-insure-name="SI">
        <i class="fa fa-home fa-2" aria-hidden="true"></i>
    </div>
    <h4>Term Life</h4>
</div>
