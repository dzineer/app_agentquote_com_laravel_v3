<a href="{{ $url }}" target="_blank" class="btn btn-primary btn-lg m-y-40">{{ $title }}</a>
