@extends('adminlte::page')

@section('title')
    {{ config('agentquote.company.name') }}
@endsection

@section('content_header')
@stop

@section('content')
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Dashboard</h5>
        </div>
    </div>
@stop