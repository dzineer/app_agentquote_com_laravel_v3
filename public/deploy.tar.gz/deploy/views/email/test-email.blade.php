@component('mail::message')
# Introduction

- [New Details](Some Link)
- [New Details](Some Link)
- [New Details](Some Link)

Thanks,<br>
Agent Quote Support

@endcomponent