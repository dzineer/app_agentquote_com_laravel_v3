@extends('layouts.file-manager-master')

@section('body')

        <script>



        </script>

        <div class="container">
            <div class="row">
                <div class="col-md-12 my-20">
                    @yield('content')
                </div>
            </div>
        </div>
        <!-- /.content-wrapper -->
@stop
