@section('run_ad')
    <!-- run ad -->
    <script>
        let ad = {!! $adString !!}
    </script>
@stop

<div id="information-box"></div>
