<header class="page-head" id="home">
    <!-- RD Navbar-->
    <div class="rd-navbar-wrap">
        @include("landing-pages.v1.pages.home.sections.nav")
    </div>

</header>
