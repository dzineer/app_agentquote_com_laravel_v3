{{--<div class="swiper-slide" data-slide-bg="{{ asset_prepend('templates/landing-pages/v1/', 'images/slider-02.jpg') }}">--}}
    <div class="swiper-slide" data-slide-bg="https://banner.aq2e.com/imagetool/ratio/rect/1920/750/444444">
    <div class="swiper-slide-caption">
        <div class="shell">
            @include("landing-pages.v1.pages.home.slides.3.shell")
        </div>
    </div>
</div>
