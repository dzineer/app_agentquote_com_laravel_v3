<section class="swiper-container swiper-slider swiper-slider-home" data-height="" data-min-height="270px" data-autoplay="5000" data-dots="true">
    <div class="swiper-wrapper">
        @include("landing-pages.v1.pages.home.slides.index")
    </div>
    <!-- Swiper Pagination-->
    <div class="swiper-pagination"></div>
</section>
