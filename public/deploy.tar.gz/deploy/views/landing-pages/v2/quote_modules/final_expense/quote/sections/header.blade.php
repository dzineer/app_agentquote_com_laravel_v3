<header class="page-head" id="home">
    <!-- RD Navbar-->
    <div class="rd-navbar-wrap">
        @include("landing-pages." . $version . ".quote_modules.final_expense.quote.sections.nav")
    </div>

</header>
