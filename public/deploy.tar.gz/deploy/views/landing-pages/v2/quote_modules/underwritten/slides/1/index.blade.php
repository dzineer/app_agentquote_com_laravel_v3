{{--<div class="swiper-slide" data-slide-bg="{{ asset_prepend('templates/landing-pages/' . $version . '/', 'images/slider-01.jpg') }}">--}}
<div class="swiper-slide" data-slide-bg="https://banner.aq2e.com/imagetool/ratio/rect/1920/750/444444">
    <div class="swiper-slide-caption">
        <div class="shell">
            @include("landing-pages." . $version . ".pages.home.slides.1.shell")
        </div>
    </div>
</div>
