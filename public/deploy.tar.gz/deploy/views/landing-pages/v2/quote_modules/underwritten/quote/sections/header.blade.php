<header class="page-head" id="home">
    <!-- RD Navbar-->
    <div class="rd-navbar-wrap">
        @include("landing-pages." . $version . ".quote_modules.underwritten.quote.sections.nav")
    </div>

</header>
