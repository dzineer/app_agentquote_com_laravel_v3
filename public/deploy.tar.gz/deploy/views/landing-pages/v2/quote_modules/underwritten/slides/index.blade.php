@include("landing-pages." . $version . ".pages.home.slides.1.index")
@include("landing-pages." . $version . ".pages.home.slides.2.index")
@include("landing-pages." . $version . ".pages.home.slides.3.index")
