{{--<div>
    <ul class="list-inline list-inline-md">
        @foreach($social_media as $media)
        <li><a class="icon {{ $media['icon'] }} icon-default" href="{{ $media['link'] }}" target="_blank"><i></i></a></li>
        @endforeach
    </ul>
</div>--}}
<div id="social-media-bar"></div>
