<div class="offset-top-5 offset-md-top-0">
    <ul class="list-inline list-inline-sm reveal-inline reval-md-block">
        <li class="text-white text-italic">Make an Appointment Now!</li>
        <li><a class="text-white text-extra-bold link-underline" href="#" data-toggle="modal" data-target="#bookAppointment">Book an Appointment</a></li>
    </ul>
</div>
