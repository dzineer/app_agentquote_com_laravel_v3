<h1 class="text-primary"><span class="text-light">Dr.</span>Mark Hoffman</h1>
<h4 class="text-gray-light veil reveal-sm-block text-regular">Dr. Mark Hoffman's dental clinic welcomes you!</h4><a class="btn btn-primary" href="#" data-toggle="modal" data-target="#bookAppointment">Book an Appointment</a>
