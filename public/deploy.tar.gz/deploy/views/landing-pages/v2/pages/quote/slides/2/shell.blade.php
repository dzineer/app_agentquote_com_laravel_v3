<div class="range range-xs-center range-md-left offset-top-0">
    <div class="cell-sm-8 cell-md-6">
        <h1 class="text-primary">Appointments</h1>
        <h3 class="small text-bold veil reveal-sm-block text-regular">Booking an appointment at our dental clinic is as easy as it gets...</h3>
        <div class="range offset-top-10 veil reveal-sm-flex">
            <div class="cell-md-10">
                <p class="text-regular veil reveal-md-block">You will be able to schedule a convenient time for your meeting with our dentists with just 2 clicks!</p>
            </div>
        </div><a class="btn btn-primary offset-top-20 offset-md-top-40" href="#" data-toggle="modal" data-target="#bookAppointment">Book an Appointment</a>
    </div>
</div>
