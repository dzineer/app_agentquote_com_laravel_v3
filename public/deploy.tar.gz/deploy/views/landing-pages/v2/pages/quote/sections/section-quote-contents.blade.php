@if( $menus['show'] )
    <section class="section-60 section-md-top-80 section-md-bottom-85" id="quote-form">
@else
    <section class="section-60 section-md-top-80 section-md-bottom-85 pt-0" id="quote-form">
@endif
    <div class="shell">

        {{--<h5 class="text-center text-gray-light mb-4">Eight Step Process To Obtaining A Life Insurance Policy</h5>--}}
        <div class="range range-xs-center">
            <div class="cell-sm-12 cell-md-12">

                <div id="quote-results" style="margin-top: 100px;">

                    <div id="quote-display">

                    </div>

                </div>

            </div>
        </div>
    </div>
</section>
