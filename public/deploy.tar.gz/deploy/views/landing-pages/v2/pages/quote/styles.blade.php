<link rel="stylesheet" type="text/css" href="//fonts.googleapis.com/css?family=Alegreya+Sans:400,800,700,400italic">
<link rel="stylesheet" href="{{ asset_prepend('templates/landing-pages/' . $version . '/', 'css/fonts.css') }}">
<link rel="stylesheet" href="{{ asset_prepend('bootstrap-4.3.1/dist/', 'css/bootstrap.css') }}">
<link rel="stylesheet" href="{{ asset_prepend('templates/landing-pages/' . $version . '/', 'css/bootstrap.css') }}">
<link href="{{ asset('vendor/toastr/dist/css/toastr.min.css') }}" rel="stylesheet">
<link rel="stylesheet" href="{{ asset_prepend('templates/landing-pages/' . $version . '/', 'css/style.css') }}">
<link rel="stylesheet" href="{{ asset_prepend('templates/landing-pages/' . $version . '/', 'css/app.css') }}">
