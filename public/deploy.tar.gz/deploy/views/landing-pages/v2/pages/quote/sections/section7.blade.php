<section class="bg-primary section-60 section-md-80">
    <div class="shell">
        <div class="range range-xs-center range-md-middle">
            <div class="cell-sm-10 cell-md-9">
                <h3 class="text-white">How we can help</h3>
                <h5 class="text-white">We offer a wide range of procedures to help you get the perfect smile.</h5>
            </div>
            <div class="cell-sm-10 cell-md-3 text-md-right offset-top-25 offset-md-top-0"><a class="btn btn-primary" href="#" data-toggle="modal" data-target="#bookAppointment">Book an Appointment</a></div>
        </div>
    </div>
</section>
