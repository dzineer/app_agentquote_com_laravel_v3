<div class="range range-xs-center range-md-left offset-top-0">
    <div class="cell-sm-8 cell-md-6">
        <h4 class="text-white text-bold">We’re always available for customers<span class="veil reveal-sm-inline"> with emergent dental problems.</span></h4>
        <p class="text-white veil reveal-sm-block">You can easily reach us 24/7 via the phone number below:</p>
        <div class="unit unit-xl-horizontal unit-lg-horizontal unit-md-horizontal unit-sm-horizontal unit-xs-vertical unit-spacing-sm offset-top-20 offset-sm-top-40">
            <div class="unit-left">
                <div class="icon fa-phone icon-circle icon-lg text-middle text-white veil reveal-sm-inline-block"></div>
            </div>
            <div class="unit-body"><a class="h1 text-white text-bold" href="tel:#">{{ $phone[0] }}</a></div>
        </div>
    </div>
</div>
