<!-- Java script-->
<script>
    const user_id = {!! $user_id !!};
    const use_logo = {!! $use_logo !!};
    const brand_logo = "{!! $brand_logo !!}";
    const brand_company = "{!! $brand_company !!}";
    debugger;
    const social_media_icons = {!! $social_media !!};
</script>
